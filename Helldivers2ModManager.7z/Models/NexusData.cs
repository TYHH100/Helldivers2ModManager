﻿namespace Helldivers2ModManager.Models;

internal sealed class NexusData
{
	public required uint ModId { get; init; }

	public required Version Version { get; init; }
}

﻿namespace Helldivers2ModManager.ViewModels.Create;

internal sealed class IntroPageViewModel : WizardViewModelBase
{
	public override bool IsValid()
	{
		return true;
	}
}
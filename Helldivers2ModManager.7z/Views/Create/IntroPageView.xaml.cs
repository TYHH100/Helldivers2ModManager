﻿using System.Windows.Controls;

namespace Helldivers2ModManager.Views.Create;

internal partial class IntroPageView : Page
{
	public IntroPageView()
	{
		InitializeComponent();
	}
}

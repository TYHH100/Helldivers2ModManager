﻿using System.Windows.Controls;

namespace Helldivers2ModManager.Views.Create;

internal partial class ChoosePageView : Page
{
	public ChoosePageView()
	{
		InitializeComponent();
	}
}

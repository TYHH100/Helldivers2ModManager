﻿using System.Windows.Controls;

namespace Helldivers2ModManager.Views;

internal partial class DashboardPageView : Page
{
	public DashboardPageView()
	{
		InitializeComponent();
	}
}
